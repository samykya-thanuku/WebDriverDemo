package com.cg.WebDriverDemo1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo2 {

	public static void main(String[] args) {
		try{
			System.setProperty("webdriver.chrome.driver","D:\\driver\\chromedriver.exe");
			
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.google.com/");
			
			WebElement searchField=driver.findElement(By.id("lst-ib"));
			searchField.sendKeys("royal enfield 350 cc");
			searchField.submit();
			
			WebElement imagesLink=driver.findElements(By.linkText("Images")).get(0);
			imagesLink.click();
			
			WebElement imagesLink1=driver.findElements(By.linkText("green")).get(0);
			imagesLink1.click();
			
			WebElement imageElement =driver.findElements(By.cssSelector("a[class=rg_l]")).get(2);
			WebElement imageLink = imageElement.findElements(By.tagName("img")).get(0);
			imageLink.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
